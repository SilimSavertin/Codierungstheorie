/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codierungstheorie;

import codierungstheorie.fields.FourField;
import codierungstheorie.fields.PrimeField;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author isthaherb
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Main(args);
    }
    
    public Main(String[] args) {
        //testOperators();
        //testMatrixOperations();
    	//testControlMatrix();
        //testGaussJordanDyn();
        //testSyndromTable();  
        //testHamming();
        //testReedMuller();
        //testPolynom();
        testBodyTable();
    }
    
    // --------------------------------
    
    public void testMatrixOperations() {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter field for matrices: ");
        int field = Integer.parseInt(in.nextLine());
        System.out.println("Enter matrix 1 (values separated by , - columns by ;) ");
        Matrix a = Utilities.getNewMatrixFromData(parseMatrixString(in.nextLine()), field);
        System.out.println("Enter matrix 2 (values separated by , - columns by ;) ");
        Matrix b = Utilities.getNewMatrixFromData(parseMatrixString(in.nextLine()), field);
        Matrix res = a.multiply(b);
        printMatrix(a);
        System.out.println("multiplied with");
        printMatrix(b);
        System.out.println("=");
        printMatrix(res);
    }
    
    public void testControlMatrix() {
	int[][] bin = {
        	{1,0,0,0,0,1,1},
		{0,1,0,0,1,0,1},
		{0,0,1,0,1,1,0},
		{0,0,0,1,1,1,1},
	};
	
        Matrix genmat = new Matrix(bin,new PrimeField(2));
	Matrix contrmat = genmat.getControlMat();
        Matrix contrmat2 = contrmat.getGeneratorMat();
		
	Matrix mul = contrmat.multiply( genmat.transpose() );
		
	System.out.print("Generatormatrix: \n" + genmat.toString() + "\n");
	System.out.print("Kontrollmatrix: \n" + contrmat.toString() + "\n");
        System.out.print("Rücktest: \n" + contrmat2.toString() + "\n");
		
	System.out.println("G * xT = \n" + mul + "\n");
    }
    
    public void testGaussJordanDyn() {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter field for matrices: ");
        int field = Integer.parseInt(in.nextLine());
        System.out.println("Enter matrix (values separated by , - columns by ;) ");
        Integer[][] data = parseMatrixString(in.nextLine());
        Matrix aMatrix = Utilities.getNewMatrixFromData(data, field);
        System.out.println("Read matrix:");
        printMatrix(aMatrix);
        System.out.println("Matrix reduced to echelon form:");
        aMatrix.reducedRowEchelonForm();
        printMatrix(aMatrix);
    }
    
    public void testSyndromTable() {
        int[][] bin = {{0,1,0,0,1},{1,0,1,1,0}}; //script
	int[][] tert = {{2,1,0},{2,0,1}}; //wiki
	int[][] quad = {{3,1,3,0,0},{1,1,0,2,3}}; //script modified 4 => 3
	
        Matrix binmat = new Matrix(bin,new PrimeField(2));
	Matrix tertmat = new Matrix(tert,new PrimeField(3));
	Matrix quadmat = new Matrix(quad,new FourField());
	
        SyndromTable binT = new SyndromTable();
	System.out.println("------Matrix------");
	System.out.print(binmat.toString());
	binT.generateSyndromTable(binmat);
	binT.printTable();
	System.out.println("------Matrix------");
	System.out.print(tertmat.toString());
	binT.generateSyndromTable(tertmat);
	binT.printTable();
	System.out.println("-------Matrix------");
	System.out.print(quadmat.toString());
	binT.generateSyndromTable(quadmat);
	binT.printTable();
    }    
    
    public void testHamming() {
        try {
            int q = 2;
            Hamming hem = new Hamming(3, new PrimeField(q));
            
            //int[][] testcode3 = {{2,0,2,0}};
            //int[][] testcode3 = {{1,0,2,1}};
            //int[][] testcode7 = {{2,0,2,0,2,0,2,2}};
            
            Matrix H = hem.getControlMat().moveUnifyerToRight();
            Matrix G = H.getGeneratorMat();
            
            // add parrity
            Matrix Gi = Hamming.addParity(G);
            Matrix Hi = Gi.getControlMat();
            
            //Matrix test = G.getControlMat();
            
            //Matrix corrupted = new Matrix(testcode3, new PrimeField(q));
            //Matrix fixed = hem.correct(corrupted);
            
            System.out.println("[" 
                    + H.columnCount() + ","
                    + (hem.m + 1) + "," 
                    + H.rowCount() + "]_"
                    + q + " Hamming code:");
            System.out.println("Kontrollmatrix H = \n" + H.toString());
            System.out.println("Generatormatrix G = \n" + G.toString());
            System.out.println("Generatormatrix mit Paritätsspalte G' = \n" + Gi.toString());
            System.out.println("Kontrollmatrix mit Paritätsspalte H' = \n" + Hi.toString());
            
            //System.out.println("Rücktest: \n" + test.toString());
            //System.out.println("\nTestwort cw = \n" + corrupted.toString());
            //System.out.println("=>\n" + fixed.toString());
        } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void testReedMuller() {
        Matrix rm = ReedMuller.G(3, 2, new PrimeField(2));
        System.out.println(rm.toString());
    } 
    
    public void testPolynom() {
        PrimeField f = new PrimeField(3);        
        Polynomial zero = new Polynomial(0, 0, f);

        Polynomial p1   = new Polynomial(1, 4, f);
        Polynomial p2   = new Polynomial(2, 1, f);
        Polynomial p3   = new Polynomial(1, 0, f);
        Polynomial p    = p1.plus(p2).plus(p3);

        Polynomial q1   = new Polynomial(2, 3, f);
        Polynomial q2   = new Polynomial(1, 2, f);
        Polynomial q3   = new Polynomial(1, 0, f);
        Polynomial q    = q1.plus(q2).plus(q3);


        Polynomial a    = p.plus(q);
        Polynomial r    = p.reduction(q);

        System.out.println("zero(x) =     " + zero);
        System.out.println("p(x) =        " + p);
        System.out.println("q(x) =        " + q);
        System.out.println("p(x) + q(x) = " + a);
        System.out.println("p(x) mod q(x) = " + r);/**/
    }
    
     public void testBodyTable() {        
        //Polynomial[] elements = BodyTable.getElements(pe, 3);
        BodyTable body = new BodyTable();
        Polynomial[] elements = body.getElements(4);
        
        System.out.println("Elements: [" + elements.length + "]");
        for(int i=0; i<elements.length; i++) {
            System.out.print(elements[i] + ", ");
        }
        System.out.println();          
        
        Polynomial f = body.getF();
        
        System.out.println("\nFunction: ");
        System.out.println("f(x) = " + f.toString());
        
        Polynomial addTable[][] = BodyTable.buildAddTable(f, elements);
        Polynomial mulTable[][] = BodyTable.buildMulTable(f, elements);
        
        int[][] aTable = BodyTable.readable(addTable, elements);
        Matrix add = new Matrix(aTable, f.getType());
        
        int[][] mTable = BodyTable.readable(mulTable, elements);
        Matrix mul = new Matrix(mTable, f.getType());
        
        System.out.println("[+]");
        System.out.println(add.toString());
        System.out.println("[*]");
        System.out.println(mul.toString());
        /**/
    }
    
   // --------------------------------
    
    public void printMatrix(Matrix matrix) {
        StringBuilder strB = new StringBuilder();
        for(int i = 0; i < matrix.rowCount(); i++) {
            strB.append("|");
            for(int j = 0; j < matrix.columnCount(); j++) {
                strB.append(matrix.get(i, j).toString());
                strB.append(j == ( matrix.columnCount() - 1 ) ? "|\n" : " " );
            }
        }  
        System.out.print(strB.toString());
    }
    
    public Integer[][] parseMatrixString(String matrixString) {        
        String[] rows = matrixString.split(";");
        Integer[][] data = new Integer[rows.length][];
        for (int i = 0; i < rows.length; i++) {
            String[] values = rows[i].split(",");
            data[i] = new Integer[values.length];
            for(int j = 0; j < values.length; j++) {
                data[i][j] = Integer.parseInt(values[j]);
            }
        }
        return data;
    }
}
