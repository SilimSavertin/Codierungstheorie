/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codierungstheorie;

import codierungstheorie.fields.PrimeField;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author isthaherb
 */
public class BodyTable<T> {
    private int p, deg, q;
    private Field type;
    
    static int[][][] zLookups = { 
        {{}},
        {{}},
        { // z2
            {},
            {},
            {1,1,1},    // 1 + x + x² 
            {1,0,1,1},  
            {1,0,0,1,1},
            {1,0,1,0,0,1},
            {1,0,0,0,0,1,1},
            {1,0,0,0,0,0,1,1},
            {1,0,1,1,1,0,0,0,1},
        },
        { // z3
            {},
            {},
            {2,1,1},
            {1,2,0,1},
            {2,0,0,1,1},
            {1,2,0,0,0,1},
            {2,0,0,0,0,1,1},
        },
        {{}},
        { // z5
            {},
            {},
            {2,1,1},
            {2,0,1,1},
            {2,3,0,1,1},
            {2,4,0,0,0,1},
            {2,0,0,0,0,1,1},
        },
        {{}},
        { // z7
            {},
            {},
            {3,1,1},
            {2,3,0,1},
            {3,1,0,1,1},
        },
    };
    
    public Polynomial[] getElements(int q) {
        int p=0;
        int g=0;
        
        for(int i=2; i<q; i++) {
            if(Utilities.isPrime(i) && (q%i==0)) {
                p = i;
            }
        }
        
        for(int i=1; i<q; i++) {
            if(Math.pow(p, i)==q) {
                g = i;
                break;
            }
        }
        
        System.out.println("p="+p+" deg="+g+" q="+q);
        this.p = p;
        this.deg = g;
        this.q = q;
        
        PrimeField pe = new PrimeField(p);
        this.type = pe;
        
        return this.getElements();
    }
    
    public Polynomial getF() {
        return new Polynomial(BodyTable.zLookups[this.p][this.deg], this.type);
    }
    
    private Polynomial[] getElements() {
        int pmax = this.p;
        
        ArrayList<Polynomial> ret = new ArrayList<Polynomial>();
        BodyTable.buildElements(0, pmax, deg, new Polynomial(0, 0, this.type), this.type, ret);
        
        // sort values
        Collections.sort(ret, new Comparator<Polynomial>() {
            @Override
            public int compare(Polynomial o1, Polynomial o2) {
                if(o1.isBigger(o2)) return 1;
                else return -1;
                //else if(o2.isBigger(o1)) return -1;
                //else return 0;
            }
        });
        
        return ret.toArray(new Polynomial[ret.size()]);
    }
    
    static void buildElements(int deg, int pmax, int degmax, Polynomial root, Field type, ArrayList<Polynomial> ret) {
        if(deg==degmax) {
            ret.add(root);
            return;
        }
        
        for(int p=0; p<pmax; p++) {
            Polynomial poly = new Polynomial(p, deg, type);
            BodyTable.buildElements(deg+1, pmax, degmax, root.plus(poly), type, ret);
        }
    }
    
    
    static Polynomial[][] buildMulTable(Polynomial fx, Polynomial[] elements) {
        Polynomial[][] res = new Polynomial[elements.length][elements.length];
        System.out.println("\nx Table: ");
        
        for(int x=0; x<elements.length; x++) {
            for(int y=0; y<elements.length; y++) {
                Polynomial value = elements[x].times(elements[y]);
                res[x][y] = value.reduction(fx);
                System.out.print(res[x][y] + " | ");
            }
            System.out.println("\n----------------------------------------");
        }
        
        return res;
    }
    
    static Polynomial[][] buildAddTable(Polynomial fx, Polynomial[] elements) {
        Polynomial[][] res = new Polynomial[elements.length][elements.length];
        System.out.println("\n+ Table: ");
        
        for(int x=0; x<elements.length; x++) {
            for(int y=0; y<elements.length; y++) {
                Polynomial value = elements[x].plus(elements[y]);
                res[x][y] = value.reduction(fx);
                System.out.print(res[x][y] + " | ");
            }
            System.out.println("\n----------------------------------------");
        }
        
        return res;
    }
    
    public static int[][] readable(Polynomial[][] data, Polynomial[] elements) {
        int[][] ret = new int[data.length][data.length];
        for(int x=0; x<data.length; x++) {
            for(int y=0; y<data.length; y++) {
                for(int e=0; e<elements.length; e++) {
                    if(data[x][y].eq(elements[e])) {
                        ret[x][y] = e;
                        break;
                    }
                }
            }
        }
        return ret;
    }
}
