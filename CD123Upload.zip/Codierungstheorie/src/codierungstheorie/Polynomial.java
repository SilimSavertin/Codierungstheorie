package codierungstheorie;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/******************************************************************************
 * Original Copyright © 2000–2011, Robert Sedgewick and Kevin Wayne. 
 * Taken from http://introcs.cs.princeton.edu/java/92symbolic/Polynomial.java.html
 * 
 * extended by Tharo Riedlinger 2017 for h_da purposes only
 ******************************************************************************/

public class Polynomial<T> 
        implements Cloneable
{
    private Field type;
    protected int[] coef;  // coefficients
    private int deg;     // degree of polynomial (0 for the zero polynomial)
    
    // a * x^b
    public Polynomial(int a, int b, Field t) {
        this.type = t;
        coef = new int[b+1];
        coef[b] = a;
        deg = degree();
    }
    
    protected Polynomial(int[] a, Field t) {
        this.type = t;
        coef = a.clone();
        deg = degree();
    }
    
    public Polynomial clone() {
        return new Polynomial(this.coef, type);
    }
    
    public int[] getCoeficients() {
        return this.coef;
    }
    
    public Field getType() {
        return this.type;
    }
    
    // return the degree of this polynomial (0 for the zero polynomial)
    public int degree() {
        int d = 0;
        for (int i = 0; i < coef.length; i++)
            if (coef[i] != 0) d = i;
        return d;
    }

    public boolean isBigger(Polynomial o) {
        if(this.degree()>o.degree()) return true;
        else if(this.degree()<o.degree()) return false;
        
        for(int i=this.coef.length-1; i>=0; i--) {
            if(this.coef[i]>o.coef[i]) return true;
            else if(this.coef[i]<o.coef[i]) return false;
        }
        
        return false;
    }
    
    // return c = a + b
    public Polynomial plus(Polynomial b) {
        Polynomial a = this;
        Polynomial c = new Polynomial(0, Math.max(a.deg, b.deg), this.type);
        
        for (int i = 0; i <= a.deg; i++) 
            c.coef[i] = (Integer) this.type.add(c.coef[i], a.coef[i]);
        for (int i = 0; i <= b.deg; i++) 
            c.coef[i] = (Integer) this.type.add(c.coef[i], b.coef[i]);

        c.deg = c.degree();
        return c;
    }

    // return (a - b)
    public Polynomial minus(Polynomial b) {
        Polynomial a = this;
        Polynomial c = new Polynomial(0, Math.max(a.deg, b.deg), this.type);

        for (int i = 0; i <= a.deg; i++) c.coef[i] = (Integer) this.type.sub(c.coef[i], a.coef[i]);
        for (int i = 0; i <= b.deg; i++) c.coef[i] = (Integer) this.type.sub(c.coef[i], b.coef[i]);
        
        c.deg = c.degree();
        return c;
    }

    // return (a * b)
    public Polynomial times(Polynomial b) {
        Polynomial a = this;
        
        int[] cdata = new int[a.deg + b.deg +1];
        for(int i=0; i<cdata.length; i++)
            cdata[i] = 0;
        Polynomial c = new Polynomial(cdata, this.type);
                
        for (int i = 0; i <= a.deg; i++) {
            for (int j = 0; j <= b.deg; j++) {
                int add = (int)this.type.multiply(a.coef[i], b.coef[j]);
                // original code was messing around at this location. Of course we
                // need to ADD equal coeficients in our result. not overwrite em (ried)
                c.coef[i+j] = (int) this.type.add(c.coef[i+j], add);
            }
        }
        c.deg = c.degree();
        return c;
    }

    // return a(b(x))  - compute using Horner's method
    public Polynomial compose(Polynomial b) {
        Polynomial a = this;
        Polynomial c = new Polynomial(0, 0, this.type);
        for (int i = a.deg; i >= 0; i--) {
            Polynomial term = new Polynomial(a.coef[i], 0, this.type);
            c = term.plus(b.times(c));
        }
        return c;
    }


    // do a and b represent the same polynomial?
    public boolean eq(Polynomial b) {
        Polynomial a = this;
        if (a.deg != b.deg) return false;
        for (int i = a.deg; i >= 0; i--)
            if (a.coef[i] != b.coef[i]) return false;
        return true;
    }


    // use Horner's method to compute and return the polynomial evaluated at x
    public T evaluate(int x) {
        throw new NotImplementedException();
        /*T p = 0;
        for (int i = deg; i >= 0; i--)
            p = coef[i] + (x * p);
        return p;/**/
    }

    // differentiate this polynomial and return it
    public Polynomial differentiate() {
        throw new NotImplementedException();
        /*
        if (deg == 0) return new Polynomial(0, 0);
        Polynomial deriv = new Polynomial(0, deg - 1);
        deriv.deg = deg - 1;
        for (int i = 0; i < deg; i++)
            deriv.coef[i] = (i + 1) * coef[i + 1];
        return deriv;/**/
    }

    // convert to string representation
    public String toString() {
        if (deg ==  0) return "" + coef[0];
        if (deg ==  1) return coef[1] + "x + " + coef[0];
        
        String s;
        if(coef[deg]>1) s = coef[deg] + "x^" + deg;
        else s = "x^" + deg;
        
        for (int i = deg-1; i >= 0; i--) {
            if      (coef[i] == 0) continue;
            //else if (coef[i]  > 0) s = s + " + " + ( coef[i]);
            //else if (coef[i]  < 0) s = s + " - " + (-coef[i]);
            else s = s + " + " + ( coef[i]);
            if      (i == 1) s = s + "x";
            else if (i >  1) s = s + "x^" + i;
        }
        return s;
    }
    
    public Polynomial reduction(Polynomial b) {
        Polynomial a = this.clone();
        while(a.degree() >= b.degree()) {
            int[] vala = a.getCoeficients();
            int[] valb = b.getCoeficients();
            int degA = vala[a.degree()] * -1;
            int degA2 = this.type.abs(degA);
            int degB = valb[b.degree()];
            int degB2 = (int)this.type.divide(1, degB);
            int adegMbdeg = a.degree() - b.degree();
            int abdeg = (int)this.type.multiply(degA2, degB2);
            
            Polynomial mid = new Polynomial(abdeg, adegMbdeg, this.type);
            a = a.plus( mid.times(b) );
        }
        return a;
    }
}