/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codierungstheorie;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import codierungstheorie.fields.PrimeField;

/**
 * 
 * @author dave
 *
 */
public class SyndromTable {
	
	//syndromtable
	private Map<String,Matrix> syndromTable;
	//transposed Matrix h
	Matrix ht;
	
	/** 
	 * generate a Syndromtable out of a Matrix h
	 * @param h Controll Matrix
	 */
	public void generateSyndromTable(Matrix h){		
            ht = h.transpose();
            int q = ht.getF().getSize();
            syndromTable = new HashMap<String,Matrix>();
            
            //do q^n times
            for (int i = 0; i < Math.pow(q,h.columnCount()); i++){
                //generate the i-th Vector
		Matrix e = generateVectors(i,q,h.columnCount());
		
                //calculate syndrom for this Vector
		Matrix syndrom = e.multiply(ht);
                
		//put vector into Syndromtable if its weight is smaller or syndrom not yet generated
		if (syndromTable.containsKey(syndrom.toString()) && syndromTable.get(syndrom.toString()).weight() <= e.weight()){
                    continue;
                }
                else{
                    syndromTable.put(syndrom.toString(), e); 
                }
            }
	}
	
	/**
	 * Single digit Matrix (Vector) representation of a decimal number with alphabet size q
	 * @param i the decimal equivalent of the Vector to generate
	 * @param q Size of the alphabet
	 * @param n the dimension of Vector
	 * @return Vector as Matrix
	 */
	private Matrix generateVectors(int i, int q, int n){
		Matrix resultVector = new Matrix(1,n,ht.getF());
		for (int k = 0; k<n;k++){
			resultVector.set(0, k, new Integer(i%q));
			i = i/q;
		}
		return resultVector;
	}
	
	/**
	 * print the Syndromtable
	 */
	public void printTable(){
		System.out.println("---SyndromTable---");
		for (Entry<String,Matrix> entry : syndromTable.entrySet())
		{
			System.out.print(entry.getKey());
		    System.out.print(entry.getValue().toString());
		    System.out.println();
		}
	}
}
