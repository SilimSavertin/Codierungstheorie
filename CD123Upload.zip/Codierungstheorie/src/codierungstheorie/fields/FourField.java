/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codierungstheorie.fields;


import codierungstheorie.Field;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 *
 * @author n3x
 * Field 4 
 */
public final class FourField extends Field<Integer> {
	
	/**
	 * The number of elements in this finite field. Must be positive and prime.
	 */
	public final int size = 4;
	 private static int[][] mult = {
             {0, 0, 0, 0}, 
             {0, 1, 2, 3}, 
             {0, 2, 3, 1}, 
             {0, 3, 1, 2} 
        };
         
        private static int[][] add = {
            {0, 1, 2, 3}, 
            {1, 0, 3, 2}, 
            {2, 3, 0, 1}, 
            {3, 2, 1, 0}
        };
        
	public Integer zero() {
		return 0;
	}
	
	public Integer one() {
		return 1;
	}
	
	public Integer add(Integer x, Integer y) {
		return add[x][y];
	}
        
        public Integer sub(Integer x, Integer y) {
		throw new NotImplementedException();
	}
	
	public Integer multiply(Integer x, Integer y) {
            if(x < 0) {
                x = negate(x * -1);
            }
            if(y < 0) {
                y = negate(y * -1 );
            }
		return mult[x][y];
	}
	
	public Integer negate(Integer x) {
            for(int i = 0; i < 4; i++) {
                if(add[x][i] == 0) 
                {return i;}
            }
            return -1; //Arrays.asList(add[x]).indexOf(0);
	}
	
	public Integer reciprocal(Integer x) {
            for(int i = 0; i < 4; i++) {
                if(mult[x][i] == 1) 
                {return i;}
            }
            return -1; //Arrays.asList(add[x]).indexOf(0);
	}
	
	
	public boolean equals(Integer x, Integer y) {
		return check(x) == check(y);
	}
	
	
	// Returns the same value if it's within the range [0, size); otherwise throws an exception.
	private int check(Integer x) {
		int y = x;
		if (y < 0 || y >= size)
			throw new IllegalArgumentException("Not an element of this field: " + x);
		return y;
	}

	@Override
	public int getSize() {
		return size;
	}
	

}
