/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codierungstheorie;

/**
 *
 * @author harald.riedlinger
 */
public class ReedMuller<T> {
    /**
     * @param m    Grad
     * @param t    Ordnung
     * @param type Number Base
     */
    public static Matrix G(int t, int m, Field type) {
        if(m==0 && t==0) throw new IllegalArgumentException();
        
        if(m==0 && t>0) {
            // 2^t times 1
            int[][] values = new int[1][(int)Math.pow(2, t)];
            for(int i=0; i<values[0].length; i++) values[0][i] = 1;
            return new Matrix(values, type);
        }
        
        if(m==t) {
            //  G(m-1, m)
            //  00 ... 01
            Matrix top = G(m,m-1,type);
            
            int[][] newline = new int[1][top.columnCount()];
            for(int i=0; i<newline[0].length; i++) {
                newline[0][i] = (i==newline[0].length-1) ? 1 : 0;
            }
            
            return Matrix.vertAdd(top, new Matrix(newline, type));
        }
        else {
            //  G(r,m-1) G(r,m-1)
            //    0    G(r-1,m-1)
            Matrix prev = G(t-1,m,type);
            Matrix top = Matrix.horAdd(prev, prev);
            
            Matrix ru = G(t-1, m-1, type);
            Matrix lu = new Matrix(new int[ru.rowCount()][ru.columnCount()], type);
            Matrix bottom = Matrix.horAdd(lu, ru);
            
            return Matrix.vertAdd(top, bottom);
        }
    }
}
