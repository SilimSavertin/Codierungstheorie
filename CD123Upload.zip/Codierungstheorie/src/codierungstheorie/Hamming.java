/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codierungstheorie;

import codierungstheorie.fields.PrimeField;
import java.util.*;
import javafx.util.Pair;

/**
 *
 * @author isthaherb
 */
public class Hamming<T> {
    Vector<String> aqList;
    Map<String, Vector<String>> aqClasses;
    
    Matrix h = null;
    Matrix ht = null;
    int q;
    int m;
    Field<T> f = null;
    
    /**
     * @param q Zahlenbasis
     * @param m Codelänge
     */
    public Hamming (int m, Field<T> type) {
      aqList = new Vector<>();
      aqClasses = new HashMap<>();
      
      this.f = type;
      this.q = type.getSize();
      this.m = m;
        
      //1. Äquivalenzklassen bestimmen
        // indexies bauen
        buildAQList();
        buildAQClasses();
        buildControlMat();
    }

    private void buildAQList() {
        buildAQList(m, "");
    }

    private void buildAQList(int pos, String parent) {
        if(pos>1) 
            for(int j=0; j<q; j++)  // excluding zero!
                buildAQList(pos-1, parent + j);
        
        else {
            for(int i=0; i<q; i++) {
                String s = parent + i;
                if(!isZeroStr(s)) aqList.add(s);
            }
        }
    }
    
    private String[] buildAQClasses() {
        //System.out.println("\nÄquivalenzklassen:");
        for(Iterator<String> it = aqList.iterator(); it.hasNext();) {
            Vector<String> line = new Vector<>();
            String value = it.next(); 

            for(int i=1; i<q; i++) {
                line.add( myMul(value, i) );
            }
            
            // avoid duplicates
            Collections.sort(line);
            boolean found = false;
            for(Vector<String> v : aqClasses.values()) {
                if(v.equals(line)) {
                    found = true;
                    break;
                }
            }
            if(found==true) continue;
            
            aqClasses.put(value, line);
            /*System.out.print("  " + value + " = { ");
            for(Iterator<String> it2 = line.iterator(); it2.hasNext();) {
                System.out.print(it2.next() + ", ");
            }
            
            System.out.println("}");/**/
        }
        
        return null;
    }
    
    public void buildControlMat() {
        int cols = this.aqClasses.size();
        int[][] data = new int[this.m][cols];
        
        int j = 0;
        
        Vector<String> sortedKeys = new Vector<>(this.aqClasses.keySet());
        Collections.sort(sortedKeys);
        
        for (int i = 0; i < sortedKeys.size(); i++) {
            for(int k=this.m-1; k>=0; k--) {
                data[k][j] = Character.getNumericValue(sortedKeys.get(i).charAt(k));
            }
            //data[0][j] = Character.getNumericValue(sortedKeys.get(i).charAt(1));
            j++;
        }
        
        this.h = new Matrix(data,this.f);
        this.ht = h.transpose();        
    }
    
    public Matrix getControlMat() {
        if(this.h==null) buildControlMat();
        return this.h;
    }
    
    public Matrix correct(Matrix word) throws Exception {        
        Matrix s = word.multiply(this.ht);
        
        // 1. von welcher/(n) spalte(n) ist s ein vielfaches?
        Pair<Integer, Integer> res = findeTeiler(s);
        
        if(res==null) throw new Exception("cannot correct value");
        
        Matrix neu = word.clone();
        T value = this.f.subtract(
                (T)neu.get(0, (int)res.getKey()), 
                (T)res.getValue()
            );
        
        neu.set(0, (int)res.getKey(), value);
        
        return neu;
    }
    
    private Pair<Integer, Integer> findeTeiler(Matrix syndrom) {
        for(int i=0; i<4; i++) {
            boolean ismul = false;
            
            
            for(int k=1; k<this.q; k++) {
                int hit = -1;
                
                //System.out.println("k = " + k);
                for(int j=0; j<h.rowCount(); j++) {
                    T is = (T)h.get(j, i);
                    T shall = (T)syndrom.get(0, j);
                    T l = this.f.multiply(is, (T)new Integer(k));
                    //System.out.print(k + " * " + is + " ? " + shall);
                    
                    if(l.equals(shall)) {
                        if(hit!=-1 && hit!=k) {
                            hit = -1;
                            //System.out.println("Illegal.");
                            break;
                        }
                        hit = k;
                    //    System.out.println(" yes.");
                    }
                    else { 
                        hit = -1;
                  //      System.out.println(" no.");
                        break;
                    }
                }
                
                //System.out.println("--");
                
                if(hit!=-1) {
                    //System.out.println("correction on pos " + (i+1) + ", corr by " + hit);
                    return new Pair(i, hit);
                }
            }
            //System.out.println("~~~~");
        }
        
        return null;
    }
    
    private String myMul(String value, int mul) {
        char[] values = value.toCharArray();        
        StringBuilder res = new StringBuilder();
        
        for(int i=0; i<values.length; i++) {
            int val = Character.getNumericValue(values[i]);
            
            T v = f.multiply(
                (T) new Integer(val),
                (T) new Integer(mul)
            );
            
            res.append(v);
        }
        
        return res.toString();
    }
    
    private boolean isZeroStr(String s) {
        return s.matches("[0]+");
    }
    
    public static Matrix addParity(Matrix G) throws Exception {
        //if(G.f.getSize() != 2) throw new Exception("Parity is only supported on binary Matrixes");
        int[][] par = new int[(int)G.rowCount()][1];
        
        for(int r=0; r<G.rowCount(); r++) {
            int res = 0;
            
            for(int c=0; c<G.columnCount(); c++) {
                res = (int)G.f.add(
                        new Integer((int)G.get(r, c)),
                        new Integer(res));
            }
            par[r][0] = res;
        }
        
        Matrix parity = new Matrix(par, G.f);        
        return Matrix.horAdd(G, parity);
    }
}