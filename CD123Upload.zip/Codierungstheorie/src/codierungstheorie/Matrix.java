/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codierungstheorie;

import com.sun.javafx.geom.AreaOp;
import java.util.ArrayList;
import java.util.Arrays;

public final class Matrix<T> implements Cloneable {
	
	/*---- Basic matrix implementation ----*/
	
	// The values of the matrix stored in row-major order, with each element initially null.
	private Object[][] values;
	
	// The field used to operate on the values in the matrix.
	Field<T> f;
	
	
	
	public Field<T> getF() {
		return f;
	}

	/**
	 * Constructs a blank matrix with the specified number of rows and columns, with operations from the specified field. All the elements are initially {@code null}.
	 * @param rows the number of rows in this matrix
	 * @param cols the number of columns in this matrix
	 * @param f the field used to operate on the values in this matrix
	 * @throws IllegalArgumentException if {@code rows} &le; 0 or {@code cols} &le; 0
	 * @throws NullPointerException if {@code f} is {@code null}
	 */
	public Matrix(int rows, int cols, Field<T> f) {
		if (rows <= 0 || cols <= 0)
			throw new IllegalArgumentException("Invalid number of rows or columns");
		if (f == null)
			throw new NullPointerException();
		
		values = new Object[rows][cols];
		this.f = f;
		
		for(int i = 0; i < rows; i++) {
			for(int j = 0; j < cols; j++) {
				set(i, j, (T) new Integer(0));
			}
    	}
	}
	        
	/**
	 * Creates an Uniform Matrix 
	 * @param dim
	 * @param f
	 */
	public Matrix(int dimension, Field<T> f) {
		if (dimension <= 0)
			throw new IllegalArgumentException("Invalid number of rows or columns");
		if (f == null)
			throw new NullPointerException();
		
		values = new Object[dimension][dimension];
		this.f = f;
		
		for(int i = 0; i < dimension; i++) {
			for(int j = 0; j < dimension; j++) {
				if(i==j) set(i, j, (T) new Integer(1));
				else set(i, j, (T) new Integer(0));
			}
    	}		
	}
	
	@SuppressWarnings("unchecked")
	public Matrix(int[][] aData,Field<T> f){
		values = new Object[aData.length][ aData[0].length];
		this.f = f;
		for(int i = 0; i < aData.length; i++) {
			for(int j = 0; j < aData[0].length; j++) {
				set(i, j, (T) new Integer(aData[i][j]));
			}
    	}
	}
	
	
	
	/**
	 * Returns the number of rows in this matrix, which is positive.
	 * @return the number of rows in this matrix
	 */
	public int rowCount() {
		return values.length;
	}
	
	
	/**
	 * Returns the number of columns in this matrix, which is positive.
	 * @return the number of columns in this matrix
	 */
	public int columnCount() {
		return values[0].length;
	}
	
	
	/**
	 * Returns the element at the specified location in this matrix. The result may be {@code null}.
	 * @param row the row to read from (0-based indexing)
	 * @param col the column to read from (0-based indexing)
	 * @return the element at the specified location in this matrix (possibly {@code null})
	 * @throws IndexOutOfBoundsException if the specified row or column exceeds the bounds of the matrix
	 */
	@SuppressWarnings("unchecked")
	public T get(int row, int col) {
		if (row < 0 || row >= values.length || col < 0 || col >= values[row].length)
			throw new IndexOutOfBoundsException("Row or column index out of bounds");
		return (T)values[row][col];
	}
	
	
	/**
	 * Stores the specified element at the specified location in this matrix. The value to store can be {@code null}.
	 * @param row the row to write to (0-based indexing)
	 * @param col the column to write to (0-based indexing)
	 * @param val the element value to write (possibly {@code null})
	 * @throws IndexOutOfBoundsException if the specified row or column exceeds the bounds of the matrix
	 */
	public void set(int row, int col, T val) {
		if (row < 0 || row >= values.length || col < 0 || col >= values[0].length)
			throw new IndexOutOfBoundsException("Row or column index out of bounds");
		values[row][col] = val;
	}
        
	/**
	 * Returns a clone of this matrix. The field and elements are shallow-copied because they are assumed to be immutable.
	 * @return a clone of this matrix
	 */
	public Matrix<T> clone() {
		int rows = rowCount();
		int cols = columnCount();
		Matrix<T> result = new Matrix<T>(rows, cols, f);
		for (int i = 0; i < values.length; i++)  // For each row
			System.arraycopy(values[i], 0, result.values[i], 0, cols);
		return result;
	}
	
	public Matrix<T> clone(int first_row, int first_col) {
		int rows = rowCount();
		int cols = columnCount();
		Matrix<T> result = new Matrix<T>(rows-first_row, cols-first_col, f);
		
		for (int i = first_row; i < values.length; i++)  // For each row
			System.arraycopy(values[i], first_col, result.values[i], 0, cols-first_col);
		
		return result;
	}
	
        public Matrix<T> clone(int first_row, int first_col, int last_row, int last_col) {
            int rows = rowCount();
            int cols = columnCount();
            
            Matrix<T> result = new Matrix<T>(last_row-first_row, last_col-first_col, f);
		
            for (int i = first_row; i < last_row; i++)  // For each row
		System.arraycopy(values[i], first_col, result.values[i], 0, last_col-first_col);
		
            return result;
	}
	/*---- Basic matrix operations ----*/
	
	/**
	 * Swaps the two specified rows of this matrix. If the two row indices are the same, the swap is a no-op.
	 * @param row0 one row to swap (0-based indexing)
	 * @param row1 the other row to swap (0-based indexing)
	 * @throws IndexOutOfBoundsException if a specified row exceeds the bounds of the matrix
	 */
	public void swapRows(int row0, int row1) {
		if (row0 < 0 || row0 >= values.length || row1 < 0 || row1 >= values.length)
			throw new IndexOutOfBoundsException("Row index out of bounds");
		Object[] temp = values[row0];
		values[row0] = values[row1];
		values[row1] = temp;
	}
	
	
	/**
	 * Multiplies the specified row in this matrix by the specified factor. In other words, row *= factor.
	 * @param row the row index to operate on (0-based indexing)
	 * @param factor the factor to multiply by
	 * @throws IndexOutOfBoundsException if the specified row exceeds the bounds of the matrix
	 */
	public void multiplyRow(int row, T factor) {
		for (int j = 0, cols = columnCount(); j < cols; j++)
			set(row, j, f.multiply(get(row, j), factor));
	}
	
	
	/**
	 * Adds the first specified row in this matrix multiplied by the specified factor to the second specified row.
	 * In other words, destRow += srcRow * factor.
	 * @param srcRow the index of the row to read and multiply (0-based indexing)
	 * @param destRow the index of the row to accumulate to (0-based indexing)
	 * @param factor the factor to multiply by
	 * @throws IndexOutOfBoundsException if a specified row exceeds the bounds of the matrix
	 */
	public void addRows(int srcRow, int destRow, T factor) {
		for (int j = 0, cols = columnCount(); j < cols; j++)
			set(destRow, j, f.add(get(destRow, j), f.multiply(get(srcRow, j), factor)));
	}
	
	
	/**
	 * Returns a new matrix representing this matrix multiplied by the specified matrix. Requires the specified matrix to have
	 * the same number of rows as this matrix's number of columns. Remember that matrix multiplication is not commutative.
	 * @param other the second matrix multiplicand
	 * @return the product of this matrix with the specified matrix
	 * @throws NullPointerException if the specified matrix is {@code null}
	 * @throws IllegalArgumentException if the specified matrix has incompatible dimensions for multiplication
	 */
	public Matrix<T> multiply(Matrix<T> other) {
		if (other == null)
			throw new NullPointerException();
		if (columnCount() != other.rowCount())
			throw new IllegalArgumentException("Incompatible matrix sizes for multiplication: " + columnCount() + "/" + other.rowCount());
		
		int rows = rowCount();
		int cols = other.columnCount();
		int cells = columnCount();
		Matrix<T> result = new Matrix<T>(rows, cols, f);
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				T sum = f.zero();
				for (int k = 0; k < cells; k++)
					sum = f.add(f.multiply(get(i, k), other.get(k, j)), sum);
				result.set(i, j, sum);
			}
		}
		return result;
	}
	
	
	/*---- Advanced matrix operation methods ----*/
	
	/**
	 * Converts this matrix to reduced row echelon form (RREF) using Gauss-Jordan elimination.
	 * Always succeeds, as long as the field follows the mathematical rules and does not throw an exception.
	 */
	public void reducedRowEchelonForm() {
		int rows = rowCount();
		int cols = columnCount();
		
		// Compute row echelon form (REF)
		int numPivots = 0;
		for (int j = 0; j < cols; j++) {  // For each column
			// Find a pivot row for this column
			int pivotRow = numPivots;
			while (pivotRow < rows && f.equals(get(pivotRow, j), f.zero()))
				pivotRow++;
			if (pivotRow == rows)
				continue;  // Cannot eliminate on this column
			swapRows(numPivots, pivotRow);
			pivotRow = numPivots;
			numPivots++;
			
			// Simplify the pivot row
			multiplyRow(pivotRow, f.reciprocal(get(pivotRow, j)));
			
			// Eliminate rows below
			for (int i = pivotRow + 1; i < rows; i++)
				addRows(pivotRow, i, f.negate(get(i, j)));
		}
		
		// Compute reduced row echelon form (RREF)
		for (int i = rows - 1; i >= 0; i--) {
			// Find pivot
			int pivotCol = 0;
			while (pivotCol < cols && f.equals(get(i, pivotCol), f.zero()))
				pivotCol++;
			if (pivotCol == cols)
				continue;  // Skip this all-zero row
			
			// Eliminate rows above
			for (int j = i - 1; j >= 0; j--)
				addRows(i, j, f.negate(get(j, pivotCol)));
		}
	}
	
	
	/**
	 * Replaces the values of this matrix with the inverse of this matrix. Requires the matrix to be square.
	 * Throws an exception if the matrix is singular (not invertible). If an exception is thrown, this matrix is unchanged.
	 * @throws IllegalStateException if this matrix is not square
	 * @throws IllegalStateException if this matrix has no inverse
	 */
	public void invert() {
		int rows = rowCount();
		int cols = columnCount();
		if (rows != cols)
			throw new IllegalStateException("Matrix dimensions are not square");
		
		// Build augmented matrix: [this | identity]
		Matrix<T> temp = new Matrix<T>(rows, cols * 2, f);
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				temp.set(i, j, get(i, j));
				temp.set(i, j + cols, i == j ? f.one() : f.zero());
			}
		}
		
		// Do the main calculation
		temp.reducedRowEchelonForm();
		
		// Check that the left half is the identity matrix
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (!f.equals(temp.get(i, j), i == j ? f.one() : f.zero()))
					throw new IllegalStateException("Matrix is not invertible");
			}
		}
		
		// Extract inverse matrix from: [identity | inverse]
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++)
				set(i, j, temp.get(i, j + cols));
		}
	}
	
	
	/**
	 * Returns the determinant of this matrix, and as a side effect converts the matrix to row echelon form (REF).
	 * Requires the matrix to be square. The leading coefficient of each row is not guaranteed to be one.
	 * Always succeeds, as long as the field follows the mathematical rules and does not throw an exception.
	 * @return the determinant of this matrix
	 * @throws IllegalStateException if this matrix is not square
	 */
	public T determinantAndRef() {
		int rows = rowCount();
		int cols = columnCount();
		if (rows != cols)
			throw new IllegalStateException("Matrix dimensions are not square");
		
		T det = f.one();
		
		// Compute row echelon form (REF)
		int numPivots = 0;
		for (int j = 0; j < cols; j++) {  // For each column
			// Find a pivot row for this column
			int pivotRow = numPivots;
			while (pivotRow < rows && f.equals(get(pivotRow, j), f.zero()))
				pivotRow++;
			
			if (pivotRow < rows) {
				// This column has a nonzero pivot
				if (numPivots != pivotRow) {
					swapRows(numPivots, pivotRow);
					det = f.negate(det);
				}
				pivotRow = numPivots;
				numPivots++;
				
				// Simplify the pivot row
				T temp = get(pivotRow, j);
				multiplyRow(pivotRow, f.reciprocal(temp));
				det = f.multiply(temp, det);
				
				// Eliminate rows below
				for (int i = pivotRow + 1; i < rows; i++)
					addRows(pivotRow, i, f.negate(get(i, j)));
			}
			
			// Update determinant
			det = f.multiply(get(j, j), det);
		}
		
		return det;
	}
	
	/**
	 * Returns the transpose of the invoking matrix by switching dimensions and appropriate values
	 * @return the transpose of the invoking matrix
	 */
    public Matrix<T> transpose() {
    	Matrix<T> A = new Matrix<T>(columnCount(), rowCount(),f);
        for (int i = 0; i < rowCount(); i++)
            for (int j = 0; j < columnCount(); j++)
        		A.set(j, i, this.get(i, j));
        return A;
    }
    
    public Matrix<T> unTranspose() {
    	Matrix<T> A = new Matrix<T>(columnCount(), rowCount(),f);
        for (int i = rowCount()-1; i>=0; i--)
            for (int j = columnCount()-1; j>=0; j--)
                A.set(j, i, this.get(i, j));
        return A;
    }
    
    
    /**
     * Standard equals function
     */
    @Override
    public boolean equals(Object other){ 
    	Matrix<T> A = this;
        if (other == null) return false;
        if (other == this) return true;
        if (!(other instanceof Matrix))return false;
        @SuppressWarnings("unchecked") // LIE!
        Matrix<T> B = (Matrix<T>) other;
        if (!A.f.getClass().equals(B.f.getClass())) return false;
        if (!(A.f.getSize() == B.f.getSize())) return false;
        if (B.rowCount() != A.rowCount() || B.columnCount() != A.columnCount()) throw new RuntimeException("Illegal matrix dimensions.");
        for (int i = 0; i < rowCount(); i++)
            for (int j = 0; j < columnCount(); j++)
                if (!f.equals(A.get(i,j),B.get(i,j))) return false;
        return true;
    }
    
    
       /**
        * Returns the weight of this Matrix. The weight is determined by the amount of values != 0
        * @return weight of the Matrix
        */
    public int weight(){
        /*int weight = 0;
        for (int i = 0; i < rowCount(); i++)
	    for (int j = 0; j < columnCount(); j++)
	        if ((int)get(i,j) != 0) weight++;
    	return weight;/**/
        return 0;
    }    
    
    /**
     * Standard toString Method for Matrix
     * @return the String representation of this Matrix
     */
    public String toString() {
        StringBuilder strB = new StringBuilder();
        for(int i = 0; i < rowCount(); i++) {
            strB.append("|");
            for(int j = 0; j < columnCount(); j++) {
                strB.append(get(i, j).toString());
                strB.append(j == (columnCount() - 1 ) ? "|\n" : " " );
            }
        }  
        return strB.toString();
    }
    
    
    public static Matrix horAdd(Matrix a, Matrix b) {
    	if(a.rowCount()!=b.rowCount() || !a.getF().equals(b.getF()))
    		throw new IllegalArgumentException();
    	
    	int cols = a.columnCount() + b.columnCount();
    	Matrix result = new Matrix( a.rowCount(), cols, a.getF());
    	
    	// copy a
		for (int i = 0; i < a.rowCount(); i++)  // For each row
			System.arraycopy(a.values[i], 0, result.values[i], 0, a.columnCount());
    	
    	// copy b
		for (int i = 0; i < b.rowCount(); i++)  // For each row
			System.arraycopy(b.values[i], 0, result.values[i], a.columnCount(), b.columnCount());
    	
    	return result;
    }
    
    public static Matrix vertAdd(Matrix a, Matrix b) {
    	if(a.columnCount()!=b.columnCount())
            throw new IllegalArgumentException();
        if(!a.getF().equals(b.getF()))
            throw new IllegalArgumentException();
    	
    	int rows = a.rowCount() + b.rowCount();
    	Matrix result = new Matrix( rows, a.columnCount(), a.getF());
    	
    	// copy a
        for (int i = 0; i < a.rowCount(); i++)  // For each row
            System.arraycopy(a.values[i], 0, result.values[i], 0, a.columnCount());
    	
    	// copy b
        for (int i = 0; i < b.rowCount(); i++)  // For each row
            System.arraycopy(b.values[i], 0, result.values[i+a.rowCount()], 0, b.columnCount());
    	
    	return result;
    }
    
    public Matrix<T> getControlMat() {
    	int r = this.rowCount();

    	Matrix<T> n = this.clone(0, r).transpose();
    	Matrix<T> u = new Matrix(n.rowCount(), this.f);

    	return Matrix.horAdd(n, u);
    }
    
    public Matrix<T> getGeneratorMat() {
        return getGeneratorMat(true);
    }
    
    /**
     * @param AE is the source data in (-A^T | E), or backwards?
     * @return 
     */
    public Matrix<T> getGeneratorMat(boolean AE) {
        // use with care. wont work on several matrix structures
    	int r = this.rowCount();
        int c = this.columnCount();
        
    	Matrix<T> n;
        if(AE==true) n = this.clone(0,0,r,c-r).unTranspose();
        else n = this.clone(0,c-r).unTranspose();
                
        //n.reducedRowEchelonForm();
    	Matrix<T> u = new Matrix(n.rowCount(), this.f);

    	return Matrix.horAdd(u, n);
    }
    
    public ArrayList<int[]> columnsAsArray() {
        int r = this.rowCount();
        int c = this.columnCount();
        ArrayList<int[]> ret = new ArrayList<>();
        
        for(int i=0; i<c; i++) {
            int[] tmp = new int[r];
            for(int j=0; j<r; j++) {
                tmp[j] = (Integer)get(j,i);
            }
            ret.add(tmp);
        }
        
        return ret;
    }
    
    public Matrix<T> moveUnifyerToRight() {
        ArrayList<int[]> u = new ArrayList<>();
        ArrayList<int[]> e = this.columnsAsArray();
        
        int r = this.rowCount();
        int c = this.columnCount();
        int[] zero = new int[r];
        
        for(int i=0; i<r; i++) {
            int[] needle = zero.clone();
            needle[i] = 1;
            
            boolean found = false;
            for(int j=0; j<e.size(); j++) {
                if(Arrays.equals(needle, e.get(j))) {
                    u.add(e.get(j));
                    e.remove(j);
                    found = true;
                    break;
                }
            }
        }
        
        int[][] arr = new int[r][e.size()];
        for(int i=0; i<r; i++) {
            for(int j=0; j<e.size(); j++) {
                arr[i][j] = e.get(j)[(r-1)-i];
            }
        }
        
        Matrix<T> newN = new Matrix(arr, this.f);
        Matrix<T> newU = new Matrix(u.size(), this.f);
        
        return Matrix.horAdd(newN, newU);
    }
}
