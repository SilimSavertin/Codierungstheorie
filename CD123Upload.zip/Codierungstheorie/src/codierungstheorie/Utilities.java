/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codierungstheorie;


import codierungstheorie.fields.FourField;
import codierungstheorie.fields.PrimeField;

/**
 *
 * @author n3x
 */
public class Utilities {

    public static int getHammingDistance(Object[] a, Object[] b) {
        if (a.length != b.length) {
            throw new IllegalArgumentException();
        }
        int h = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i] != b[i]) {
                h++;
            }
        }
        return h;
    }

    public static Matrix getNewMatrixFromData(Integer[][] data, int field) {
        Matrix matrix;
        if (field <= 3) {
            matrix = new Matrix(data.length, data[0].length, new PrimeField(4));
        } else if (field == 4) {
            matrix = new Matrix(data.length, data[0].length, new FourField());
        }
        else {
        return null;
        }

        for (int i = 0; i < matrix.rowCount(); i++) {
            for (int j = 0; j < matrix.columnCount(); j++) {
                matrix.set(i, j, data[i][j]);
            }
        }
        
        return matrix;
    }
    
    
    public static boolean isPrime(int num) {
        if (num < 2) return false;
        if (num == 2) return true;
        if (num % 2 == 0) return false;
        for (int i = 3; i * i <= num; i += 2)
            if (num % i == 0) return false;
        return true;
    }
}